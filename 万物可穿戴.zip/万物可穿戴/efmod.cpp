//
// Created by EternalFuture゙ on 2025/3/23.
//

#include "efmod_core.hpp"
#include "TEFMod.hpp"
#include "Logger.hpp"
#include "BaseType.hpp"

// 全局日志对象和API接口指针
TEFMod::Logger* g_log;
TEFMod::TEFModAPI* g_api;

// 存储物品字段指针的结构体，用于后续快速访问
struct ItemFields {
    TEFMod::Field<int>* headSlot;      // 头部装备槽字段
    TEFMod::Field<int>* bodySlot;      // 身体装备槽字段
    TEFMod::Field<int>* legSlot;       // 腿部装备槽字段
    TEFMod::Field<bool>* accessory;    // 是否为饰品的标记字段
} g_item;

// 原始函数指针，用于保存 Item::ResetStats 的原函数
void (*original_ResetStats)(TEFMod::TerrariaInstance, int, bool, TEFMod::TerrariaInstance);

// 钩子函数的声明，将替换原函数
void ResetStats_T(TEFMod::TerrariaInstance, int, bool, TEFMod::TerrariaInstance);

// 钩子模板：包含要替换的函数指针以及一个函数数组（用于存放多个钩子）
inline TEFMod::HookTemplate T_ResetStats {
    reinterpret_cast<void*>(ResetStats_T),  // 替换后的函数
    {  }                                     // 钩子函数数组（后续可由框架填充）
};

/**
 * 钩子函数主体
 * 先调用原始函数，再依次执行注册在 FunctionArray 中的所有钩子
 */
void ResetStats_T(TEFMod::TerrariaInstance i, int t, bool n, TEFMod::TerrariaInstance v) {
    original_ResetStats(i, t, n, v);  // 执行原函数逻辑
    // 遍历并调用所有附加的钩子函数
    for (auto fun: T_ResetStats.FunctionArray) {
        if(fun) 
            reinterpret_cast<void(*)(TEFMod::TerrariaInstance, int, bool, TEFMod::TerrariaInstance)>(fun)(i, t, n, v);
    }
}

/**
 * 实际的钩子逻辑：当物品的任一装备槽位（头/身/腿）被设置时，将其标记为饰品
 */
void Hook_ResetStats(TEFMod::TerrariaInstance self, int type, bool noMatCheck, TEFMod::TerrariaInstance variant) {
    // 检查头部、身体或腿部槽位是否有效（>=0）
    g_item.legSlot->Set(0, self);
    g_item.bodySlot->Set(0, self);
    g_item.headSlot->Set(0, self);
    g_item.accessory->Set(true, self);        // 将 accessory 字段设为 true
}

/**
 * 模组主类，继承自 EFMod 框架
 */
class Everything final : public EFMod {
public:

    /**
     * 模组初始化阶段
     */
    int Initialize(const std::string &path, MultiChannel *multiChannel) override { return 0; }

    /**
     * 模组加载阶段：获取全局 API 和日志对象，初始化日志
     */
    int Load(const std::string &path, MultiChannel* channel) override {
        // 从通信管道中获取 TEFModAPI 接口
        g_api = channel->receive<TEFMod::TEFModAPI*>("TEFMod::TEFModAPI");
        // 创建日志器，标签为 "Everything-EternalFuture゙"
        g_log = channel->receive<TEFMod::Logger*(*)(const std::string& Tag, const std::string& filePath, const std::size_t)>("TEFMod::CreateLogger")("Everything-EternalFuture゙", "", 0);

        g_log->init();  // 初始化日志系统

        return 0;
    }

    /**
     * 模组卸载阶段
     */
    int UnLoad(const std::string &path, MultiChannel *multiChannel) override { return 0; }

    /**
     * 模组发送数据阶段：向框架注册钩子和字段描述符
     */
    void Send(const std::string &path, MultiChannel* channel) override {
        // 注册 ResetStats 函数的钩子，将原函数替换为 T_ResetStats，并附加 Hook_ResetStats
        channel->receive<TEFMod::TEFModAPI*>("TEFMod::TEFModAPI")->registerFunctionDescriptor({
            "Terraria", "Item", "ResetStats", "hook>>void", 1, &T_ResetStats, { reinterpret_cast<void*>(Hook_ResetStats) }
        });

        // 注册需要访问的物品字段名称
        const char* fields[] = {"accessory","legSlot","bodySlot","headSlot"};
        for (auto& name : fields) {
            channel->receive<TEFMod::TEFModAPI*>("TEFMod::TEFModAPI")->registerApiDescriptor({"Terraria", "Item", name, "Field"});
        }
    }

    /**
     * 模组接收数据阶段：获取字段的访问器以及原始函数指针
     */
    void Receive(const std::string &path, MultiChannel* channel) override {
        // 获取解析整型字段和布尔型字段的函数
        const auto ParseIntField = channel->receive<TEFMod::Field<int>*(*)(void*)>(
            "TEFMod::Field<Int>::ParseFromPointer");
        const auto ParseBoolField = channel->receive<TEFMod::Field<bool>*(*)(void*)>(
            "TEFMod::Field<Bool>::ParseFromPointer");

        // 通过 API 获取各字段的原始指针，并转换为 Field 对象
        g_item.accessory = ParseBoolField(g_api->GetAPI<void*>(
            {"Terraria", "Item", "accessory", "Field"}));
        g_item.legSlot = ParseIntField(g_api->GetAPI<void*>(
            {"Terraria", "Item", "legSlot", "Field"}));
        g_item.bodySlot = ParseIntField(g_api->GetAPI<void*>(
            {"Terraria", "Item", "bodySlot", "Field"}));
        g_item.headSlot = ParseIntField(g_api->GetAPI<void*>(
            {"Terraria", "Item", "headSlot", "Field"}));
        // 获取原始 ResetStats 函数指针，以便在钩子中调用
        original_ResetStats = g_api->GetAPI<void(*)(TEFMod::TerrariaInstance, int, bool, TEFMod::TerrariaInstance)>(
            {"Terraria", "Item", "ResetStats", "old_fun", 1});
    }

    /**
     * 返回模组元数据
     */
    Metadata GetMetadata() override {
        return {
            "Everything",               // 模组名称
                "NinetyQWQ",         // 作者
                "1.0.0",                   // 版本号
                20250517,                  // 构建日期
                ModuleType::Game,           // 模块类型
                {
                    false                  // 其他标志（如是否允许热重载等）
                }
        };
    }
};

/**
 * 导出函数：创建模组实例（供框架调用）
 */
EFMod* CreateMod() {
    static Everything instance;  // 单例实例
    return &instance;
}